import 'package:get_it/get_it.dart';

import 'package:chatapp_firebase/service/push_notificaion_service.dart';

GetIt locator = GetIt.instance;

void setupLocator() {
  locator.registerLazySingleton(() => PushNotificationService());
}

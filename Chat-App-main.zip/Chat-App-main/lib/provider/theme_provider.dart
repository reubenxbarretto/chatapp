import 'package:flutter/material.dart';

class ThemeProvider extends ChangeNotifier {
  ThemeMode themeMode = ThemeMode.light;
  bool get isDarkMode => themeMode == ThemeMode.dark;

  void toggleTheme(bool value) {}
}

class MyThemes {
  static final darkTheme = ThemeData(
      scaffoldBackgroundColor: Colors.grey.shade900,
      primaryColor: Color.fromARGB(255, 86, 0, 184),
      secondaryHeaderColor: Colors.white,
      colorScheme: ColorScheme.dark(),
      iconTheme: IconThemeData(color: Color.fromARGB(255, 86, 0, 184)));

  static final lightTheme = ThemeData(
    scaffoldBackgroundColor: Colors.white,
    primaryColor: Color.fromARGB(255, 86, 0, 184),
    secondaryHeaderColor: Color.fromARGB(255, 0, 0, 0),
    colorScheme: ColorScheme.light(),
  );
}

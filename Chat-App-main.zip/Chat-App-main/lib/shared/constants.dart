import 'package:flutter/material.dart';

class Constants {
  static String appId = "1:120940648311:web:e9071165c08ce40451b372";
  static String apiKey = "AIzaSyDT38FbvTq2-PqHv3vDVOSvokRk9SSz5X4";
  static String messagingSenderId = "120940648311";
  static String projectId = "chat-a76cc";
  final primaryColor = Color.fromARGB(255, 24, 56, 235);
}
